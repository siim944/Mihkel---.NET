﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;

namespace DiseaseDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            var diseasesCSV = File.ReadAllLines("Diseases.csv"); // Copy original file
            char[] borderOfSymptoms = new char[] { ',' }; // Needed later to know location of "border" where to cut symptoms one by one

            //////////////////////////////////////////////////////////////////////////////////// TASK 1 (1)

            List<string> symptomsCountAndDisease = new List<string>(); // MODIFIED

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Three most popular diseases:");
            Console.ResetColor();
            for (int i = 0; i < diseasesCSV.Length; i++)
            {
                var pieces2 = diseasesCSV[i].Split(new[] { ',' }, 2); // Split list what includes both disease and symptoms into two at first comma
                var commas = pieces2[1].Count(c => c == ','); // Reads how many commas has a disease string. So we know how many symptoms there are
                commas += 1;
                // If there are more than one symptoms, change grammar to first one, else second one
                if (Convert.ToInt32(commas) > 1) 
                     symptomsCountAndDisease.Add(commas + " symptoms on " + pieces2[0]);
                 else
                     symptomsCountAndDisease.Add(commas + " symptom on " + pieces2[0]);
            }

            var descendingOrder = symptomsCountAndDisease.OrderByDescending(i => i); // Order by numbers
            var first2 = descendingOrder.Take(3); // 3 most popular diseases
          
            foreach (var item in first2) // Write out 3 most popular diseases
            {
                Console.WriteLine(item);
            }

            //////////////////////////////////////////////////////////////////////////////////// TASK 1 (2 & 3)

            List<string> dis_sympts = new List<string>(); // Stored with symptoms from diseases
            List<string> sym1 = new List<string>(); // Stored with symptoms one by one


            for (int i = 0; i < diseasesCSV.Length; i++) 
            {
                // Split list what includes both disease and symptoms into two at first comma
                var pieces2 = diseasesCSV[i].Split(new[] { ',' }, 2);
                dis_sympts.Add(pieces2[1]);
            }
           
            for (int i = 0; i < dis_sympts.Count; i++) // Split symptoms from a longer string and put them one by one into array (massiiv)
            {
                string[] array2 = dis_sympts[i].Split(borderOfSymptoms, 
                    StringSplitOptions.RemoveEmptyEntries);
                foreach (string entry in array2)
                {
                    sym1.Add(entry);
                }
            }
          
            List<string> uniqueSymptoms = new List<string>(); // Stored with unique symptoms
            List<string> uniqueSymptomsTextAndNumber = new List<string>(); // Stored with disease name and it's symptoms
            
            sym1.Sort(); // Sort symptom names in alphabetical order
            var q1 = from x in sym1 // Read how many same symptoms there are and order numbers by descending
                      group x by x into g
                      let count3 = g.Count()
                      orderby count3 descending
                      select new { Value = g.Key, Count = count3 };

            foreach (var x in q1) // store
            {
                uniqueSymptoms.Add(x.Value); // Task 1 (2) answer stored
                uniqueSymptomsTextAndNumber.Add(x.Value + ":" + Convert.ToString(x.Count)); // Task 1 (3) answer stored

            }
           
            /* Task 1 (2) answer */
            Console.Write("\nThere are ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0}", uniqueSymptoms.Count);
            Console.ResetColor();
            Console.WriteLine(" unique symptoms in the database.\n");

            for (int y = 0; y < uniqueSymptomsTextAndNumber.Count; y++) // Remove whitespaces from the beginning of symptoms names
            {
                string trimmed = uniqueSymptomsTextAndNumber[y].TrimStart();
                uniqueSymptomsTextAndNumber[y] = trimmed;
            }
            /* Task 1 (3) answer */
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Three most popular symptoms: ");
            Console.ResetColor();
            var first = uniqueSymptomsTextAndNumber.Take(3); // 3 most popular symptoms
            foreach (string s in first)
            {
                Console.WriteLine(s);
            }
            


            beginning: // Marked as beginning of next last two tasks
            
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\nWrite 2 or 3 in order to activate next task");
            Console.ResetColor();

            /* User can choose which task to activate */
            Console.ForegroundColor = ConsoleColor.Cyan;
            string chooseTask = Console.ReadLine(); // Read requested task
            Console.ResetColor();

            if (chooseTask == "2") goto task2;
            if (chooseTask == "3") goto task3;
            if (chooseTask != "2" && chooseTask != "3")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nYou must write only number 2 or 3");
                Console.ResetColor();
                goto beginning;
            }

            //////////////////////////////////////////////////////////////// // TASK 2

            task2:
            Console.Write("Write symptoms you have. EXAMPLE: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("accelerated mutation, impaired judgment\n");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Cyan;
            string symptomQ = Console.ReadLine(); // Read requested symptom(s)         
            Console.ResetColor();

            string[] symptomsArray = symptomQ.Split(borderOfSymptoms, // Put written symptoms one by one into array
                   StringSplitOptions.RemoveEmptyEntries);

            /* Remove whitespaces at the beginning of the symptoms name AND put them to lower case */
            for (int y = 0; y < symptomsArray.Length; y++) 
            {
                string s = symptomsArray[y].Trim().ToLower();
                string trimmed = s;
                symptomsArray[y] = trimmed;
            }
            
            List<int> symptomsMatchList = new List<int>(); // Stored with matched symptoms IDs
            List<string> symptomsMatchList2 = new List<string>(); // Stored with diseases IDs and how many matches it has
            List<string> diseasesList = new List<string>(); // Stored with diseases names UNIQUE

            List<string> symptomsList = new List<string>();

            for (int i = 0; i < diseasesCSV.Length; i++) // Store diseases names one by one
            {
                var pieces2 = diseasesCSV[i].Split(new[] { ',' }, 2);
                diseasesList.Add(pieces2[0]); 
            }
            
            foreach (var symptom in dis_sympts) // Copy symptoms of diseases
            {
                symptomsList.Add(symptom);
            }

            string[,] disSymArray = new string[diseasesCSV.Length, uniqueSymptoms.Count]; // Make 2D array to store symptoms

            for (int x = 0; x < disSymArray.GetLength(0); x++)
            {
                {
                    /* Split symptomsListDB symptoms and put them into another list one by one */
                    List<string> numbers = symptomsList[x].Split(',').ToList<string>(); 

                    for (int y = 0; y < numbers.Count; y++) // Remove whitespaces from the beginning of symptoms names
                    {
                        string trimmed = numbers[y].TrimStart();
                        disSymArray[x, y] = trimmed;
                    }
                }
            }

            /* Add matched diseases ID-s into list (if a disease has for example 2 matches, add its ID twice) */
            for (int q = 0; q < symptomsArray.Length; q++) // How many symptoms are written
            {
                for (int i = 0; i < disSymArray.GetLength(0); i++)
                    for (int j = 0; j < disSymArray.GetLength(1); j++)
                        if (disSymArray[i, j] == symptomsArray[q])  // If symptom in 2D array equals asked symptom, put diseases IDs into the list
                        {
                            symptomsMatchList.Add(i);
                        }
            }
            
            var q2 = from x in symptomsMatchList // What is diseases IDs and read how many duplicated matched IDs there are
                      group x by x into g
                      let count3 = g.Count()
                      orderby count3 descending
                      select new { Value = g.Key, Count = count3 };
            
            foreach (var x in q2) // Store list with diseases IDs and how many duplicated matched IDs there are
            {
                symptomsMatchList2.Add(x.Value + ":" + Convert.ToString(x.Count)); 
            }

            bool oneMatch = false; // Boolean to check if there were any matches

            for (int i = 0; i < symptomsMatchList2.Count; i++) // Do it as many times diseases were put into symptomsMatchDB2
            {
                var pieces3 = symptomsMatchList2[i].Split(new[] { ':' }, 2); // Split disease ID number and how many matches it has
                /* Check if written symptoms count equals matched symptoms count */
                if (Convert.ToInt32(pieces3[1]) == symptomsArray.Length) 
                {
                    oneMatch = true; 

                    /* If there are more than one matched symptoms, change grammar to first one, else second one */
                    if (Convert.ToInt32(pieces3[1]) > 1)
                    {
                        /* Take disease name by disease's row in list */
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(diseasesList[Convert.ToInt32(pieces3[0])] + " disease has " + pieces3[1] + " matches");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(diseasesList[Convert.ToInt32(pieces3[0])] + " disease has " + pieces3[1] + " match");
                        Console.ResetColor();
                    }
                }
                else if (oneMatch != true) // If a symptom was written correctly but others not OR too many symptoms were written
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nZERO MATCHES but at least one symptom was written correctly! \n\nOr too many symptoms were written!");
                    Console.ResetColor();
                    goto beginning;
                }
            }
            if (symptomsMatchList.Count < 1)
            {
                if (symptomsArray.Length < 2)
                {
                    Console.WriteLine(symptomsArray.Length);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("You wrote a symptom wrong!");
                    Console.ResetColor();
                }
                else if (symptomsArray.Length > 1)
                {
                    Console.WriteLine(symptomsArray.Length);

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("You wrote all your symptoms wrong!");
                    Console.ResetColor();
                }
            }

            goto beginning;

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////// // TASK 3

            task3:
            
            List<string> symptomsCounted = new List<string>(); // count how many symptoms there were at the beginning

            List<string> diseasesUpdate = new List<string>(); // Needed to know how many diseases are possible to have after answering
            List<string> last_search_for_question = new List<string>(); // Symptom name and (how many in DB) -> not actually needed
            List<string> dis_symptoms = new List<string>(); // It will help to store symptoms one by one
            
            List<string> questionable_syms = new List<string>(); // find all available symptoms to ask
            List<string> symptoms_DO_NOT_ASK = new List<string>(); //save asked symptoms

            int readLastDiseases = 0; // read how many diseases there were before error comes.

            foreach (var item in diseasesCSV) // copy original files
            {
                diseasesUpdate.Add(item);
            }            
            
            foreach (var x in q1) // q10 is stored with all symptoms in DB
            {
                symptomsCounted.Add(x.Value);  // to read how many symptoms are in DB
            }

            for (int f = 0; f < symptomsCounted.Count; f++)
            {
                if (symptomsCounted.Count < 2) // Check if there is one or more Disease in DB
                {
                    Console.WriteLine("Less than 2 symptoms in Database!");
                    goto beginning;
                }
                else
                {
                    /* Clear lists to find next question to ask */
                    dis_symptoms.Clear();
                    questionable_syms.Clear();
                    last_search_for_question.Clear();

                    for (int i = 0; i < diseasesUpdate.Count; i++) // add all symptoms in list
                    {
                        // split list what includes both disease and symptoms into two at first comma
                        var pieces2 = diseasesUpdate[i].Split(new[] { ',' }, 2); 
                        dis_symptoms.Add(pieces2[1]);
                    }

                    for (int i = 0; i < dis_symptoms.Count; i++) // Split symptoms from a longer string and put them one by one into array (massiiv)
                    {
                        string[] array2 = dis_symptoms[i].Split(borderOfSymptoms, 
                            StringSplitOptions.RemoveEmptyEntries);
                        foreach (string entry in array2)
                        {
                            questionable_syms.Add(entry);
                        }
                    }

                    var q3 = from x in questionable_syms // Read how many same symptom ID there are
                                 group x by x into g
                                 let count3 = g.Count()
                                 select new { Value = g.Key, Count = count3 };
                    
                    foreach (var x in q3) // Add questionable questions into list
                    {
                        last_search_for_question.Add(x.Value + ":" + Convert.ToString(x.Count)); 
                    }

                    if (diseasesUpdate.Count == 1) // check if patient disease is appeared
                    {
                        // split list what includes updated info about both disease and symptoms into two at first comma
                        var pieces2 = diseasesUpdate[0].Split(new[] { ',' }, 2); 
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("You have " + pieces2[0]);
                        Console.ResetColor();
                        goto beginning;
                    }
                    if (diseasesUpdate.Count < 1) 
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        /* commented because "readLastDiseases" actually gives only last diseases count not symptoms BUT it's still interesting code  */

                        //  Console.WriteLine("\nNO DISEASE! \nThe last {0} possible diseases had same symptoms. \nYou gave me wrong information!\n", readLastDiseases );
                        Console.WriteLine("\nNO DISEASE! \nThe last two or more possible diseases had same symptoms. \nYou gave me wrong information!\n");
                        Console.ResetColor();
                        goto beginning;
                    }
                    
                    int how_many_yes = 0;
                    
                    if (symptoms_DO_NOT_ASK.Count != 0) // check if YES was told earlier
                    {
                        for (int k = 0; k < symptoms_DO_NOT_ASK.Count; k++)
                        {
                            how_many_yes = k + 1; //  Without it it asks first question twice
                        }
                    }
                   var symptomName = last_search_for_question[how_many_yes].Split(new[] { ':' }, 2); // Take questionable symptom

                    /* Ask the question */
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Do you have {0}?", symptomName[0]);
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("Write yes/no ONLY!");
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    string answerToQuestion = Console.ReadLine();
                    Console.ResetColor();

                    if (answerToQuestion == "no")
                    {
                        readLastDiseases = diseasesUpdate.Count; //
                        diseasesUpdate.RemoveAll(u => u.Contains(symptomName[0])); // Remove disease what INCLUDES asked symptom

                        if (diseasesUpdate.Count > 1) // Needed to NOT show diseases list. Instead just say the disease what patient has
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Diseases possible: ");
                            Console.ResetColor();

                            foreach (var item in diseasesUpdate) // Write list of diseases that are possible
                            {
                                Console.WriteLine(item);
                            }
                        }
                    }
                    if (answerToQuestion == "yes")
                    {
                        symptoms_DO_NOT_ASK.Add(symptomName[0]); // save asked symptoms
                        readLastDiseases = diseasesUpdate.Count; // read how many diseases there were before error comes.
                        diseasesUpdate.RemoveAll(u => !u.Contains(symptomName[0])); // Remove disease what does NOT include asked symptom

                        if (diseasesUpdate.Count > 1) // Needed to NOT show diseases list. Instead just say the disease what patient has
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Diseases possible: ");
                            Console.ResetColor();
                            foreach (var item in diseasesUpdate) // Write list of diseases that are possible
                            {
                                Console.WriteLine(item);
                            }
                        }
                    }
                }
            }
              goto beginning; 
              Console.ReadLine();
        }
    }
}

